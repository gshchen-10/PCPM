package utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import utils.DBScanCluster.DBSCAN;
import utils.DBScanCluster.DPoint;

public class SeqVerticalDatabase {
	
	public RetailDatabase retailDatabase = null;
	public Map<Integer, ArrayList<Date>> productsSalesRecord;

	public SeqVerticalDatabase(RetailDatabase database) throws ParseException {
		
		productsSalesRecord = new HashMap<>();		
		this.retailDatabase = database;
	}

	public int periodicClusterPatternMining(float coefficientOfVariation, float noiRat, int eps, float minpts) throws ParseException {
		
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");

		for (int i = 0; i < retailDatabase.getCustomersListSize(); i++) {
			Customer cust = retailDatabase.getCustomersList().get(i);
			for (int j = 0; j < cust.getCustOrderSeqSize(); j++) {
				Order ord = cust.getCustOrderSeq().get(j);
				String orderDate = ord.orderDate;
				Date dat = formatter.parse(orderDate);
				for (int k = 0; k < ord.getOrdProductsListSize(); k++) {
					int productId = ord.getOrdProductsList().get(k);
					productsSalesRecord.putIfAbsent(productId, new ArrayList<>());
					productsSalesRecord.get(productId).add(dat);
				}
			}
		}		
	
		List<PeriodicClusterPattern> periodicClustPatts = new ArrayList<>();
		Date beginDate = formatter.parse(retailDatabase.beginDate);
		Date endDate = formatter.parse(retailDatabase.endData);		
		int days = (int)((endDate.getTime() - beginDate.getTime()) / (1000 * 60 * 60 * 24));
		
		for (Entry<Integer, ArrayList<Date>> entry : productsSalesRecord.entrySet()) {
			Collections.sort(entry.getValue());
			ArrayList<DPoint> dataset = generateDataset(entry.getValue(), beginDate);
			DBSCAN dbscan = new DBSCAN(dataset);
			int aveg = (int)(dataset.size() / (float) days);
			if (aveg == 0)
				aveg = 1;
			Map<Integer, ArrayList<Integer>> clusterIdToData = dbscan.Cluster(eps, (int)(aveg * minpts));
			
			if (clusterIdToData.entrySet().size() > 2) {
				ArrayList<Double> clusterCent = new ArrayList<>();
				float noiseRatio = 0.0f;
				for (Entry<Integer, ArrayList<Integer>> ent : clusterIdToData.entrySet()) {						
					if (ent.getKey() != -1) {
						Collections.sort(ent.getValue());
						int min = ent.getValue().get(0);
						int max = ent.getValue().get(ent.getValue().size() - 1);
						double cent = (min + max) / 2.0f;
						clusterCent.add(cent);
					} else {
						noiseRatio = (ent.getValue().size() / (float)entry.getValue().size());
					}
				}
				
				ArrayList<Double> periods = new ArrayList<>();
				Collections.sort(clusterCent);

				int k = 0;
				for (; k < clusterCent.size() - 1; k++) {
					periods.add(clusterCent.get(k + 1).doubleValue() - clusterCent.get(k).doubleValue());
				}
				
				Collections.sort(periods);
				if (periods.get(periods.size() - 1) == 0)
					continue;
				int f = (int) Math.ceil(days / (periods.get(periods.size() - 1)));
				int freq = f > 2 ? f : 2;
				
				if (periods.size() >= freq) {
					double mean = meanImperative(periods);
					double vari = varianceImperative(periods, mean);
					double standvari = Math.sqrt(vari);			
					if (standvari/mean <= coefficientOfVariation && noiseRatio <= noiRat) {
						PeriodicClusterPattern newPattern = new PeriodicClusterPattern(entry.getKey(), clusterCent.size(), noiseRatio, (float)mean, (float)standvari);						
						periodicClustPatts.add(newPattern);	
					}					
				}				
			}
		}
		MemoryLogger.getInstance().checkMemory();
		return periodicClustPatts.size();

	}
	
	private ArrayList<DPoint> generateDataset(ArrayList<Date> prodSalDatSeq, Date begDate) {
		
		ArrayList<DPoint> allPoint = new ArrayList<>();

		for (int i = 0; i < prodSalDatSeq.size(); i++) {
			long timeDiff = prodSalDatSeq.get(i).getTime() - begDate.getTime();
			DPoint tdp = new DPoint((int)(timeDiff / (1000 * 60 * 60 * 24)));
			allPoint.add(tdp);			
		}
		return allPoint;
	}
	
	private double meanImperative(List<Double> population) {
		double average = 0.0;
		for (double p : population) {
			average += p;
		}
		average /= population.size(); 		
		return average;
	}
	
	private double varianceImperative(List<Double> population, double ave) {
		double average = ave; 
		double variance = 0.0;
		for (double p : population) {
			variance += (p - average) * (p - average);
		}
		return variance / population.size();
	}

}
