package utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

public class RetailDatabase {
	
	private Map<String, Integer> customersToIndex = new HashMap<>();
	private List<Customer> customersList = new ArrayList<>();
	
	public String beginDate = null;
	public String endData = null;

	public RetailDatabase(String inputfile) {
		LoadData(inputfile);
	}

	private void LoadData(String inputfile) {
		try {
			FileInputStream fin = new FileInputStream(new File(inputfile));
			BufferedReader in = new BufferedReader(new InputStreamReader(fin));
			String line = "";
			while ((line = in.readLine()) != null) {

				if (line.isEmpty() == true || line.startsWith("%") || line.charAt(0) == '@' || line.charAt(0) == '#')
					continue;
				if (line.length() == 0)
					continue;
				
				ArrayList<String> recordline = new ArrayList<>();
				StringTokenizer tokenizer = new StringTokenizer(line);
				while (tokenizer.hasMoreElements()) {
					recordline.add(tokenizer.nextToken());
				}
				AddCustomer(new Customer(recordline.get(0), recordline.get(1), recordline.get(2), Integer.parseInt(recordline.get(3))));
			}				
			in.close();
		}
		catch(IOException e) {
			e.printStackTrace();
		}

	}
	
	private void AddCustomer(Customer customer) {
		if (customersToIndex.get(customer.customerId) == null) {
			customersToIndex.put(customer.customerId, customersList.size());
			customersList.add(customer);
		} else {
			int custIndex = customersToIndex.get(customer.customerId);
			customersList.get(custIndex).AddOrderList(customer.getCustomerOrderList());
		}
	}
	
	public List<Customer> getCustomersList() {
		return customersList;
	}
	
	public int getCustomersListSize() {
		return customersList.size();
	}
	
	public Map<String, Integer> getCustomersToIndex() {
		return customersToIndex;
	}

	public void Preprocessing() {
		
		for (int i = 0; i < customersList.size(); i++) {
			customersList.get(i).sortOrderByOrderDate();
		}
		
		Map<String, Order> timeStamp = new HashMap<>();
		for (int i = 0; i < customersList.size(); i++) {
			for (int j = 0; j < customersList.get(i).getCustOrderSeqSize(); j++) {
				String time = customersList.get(i).getCustOrderSeq().get(j).orderDate;
				timeStamp.put(time, customersList.get(i).getCustOrderSeq().get(j));
			}
		}
		SortTimeStamp(timeStamp);

	}
	
	private void SortTimeStamp(Map<String, Order> timeStamp) {
		
		List<Map.Entry<String, Order>> timeStampListAfterSord = new ArrayList<Map.Entry<String, Order>>(timeStamp.entrySet());		
		Collections.sort(timeStampListAfterSord, new Comparator<Map.Entry<String, Order>>() {
			public int compare(Map.Entry<String, Order> o1, Map.Entry<String, Order> o2) {
				return (o1.getValue().compareTo(o2.getValue()));
			}
		});
		
		beginDate = timeStampListAfterSord.get(0).getValue().orderDate;
		endData = timeStampListAfterSord.get(timeStampListAfterSord.size() - 1).getValue().orderDate;

	}
	
}