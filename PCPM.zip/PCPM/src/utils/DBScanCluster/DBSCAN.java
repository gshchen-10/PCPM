package utils.DBScanCluster;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;

public class DBSCAN {
	
	private int mClusterID;
	private ArrayList<DPoint> mCorePoints;
	public ArrayList<DPoint> dataset;
	
	public DBSCAN(ArrayList<DPoint> allPoint) {
		
		dataset = allPoint;
		
	}

	public Map<Integer, ArrayList<Integer>> Cluster(double eps, int minPts) {
		
		int numPoint = dataset.size();
		
		mCorePoints = new ArrayList<>();
		for (int i = 0; i < numPoint; i++) {
			for (int j = 0; j < numPoint; j++) {
				double dist = distance(dataset.get(i), dataset.get(j));
				if (dist <= eps) {
					dataset.get(i).pts++;
					if (dataset.get(i).pts >= minPts) {
						dataset.get(i).pointType = "PointType_CORE";
						dataset.get(i).inOrigId = i;
						mCorePoints.add(dataset.get(i));
						break;
					}
				}
			}
		}
		
		int numCorePoint = mCorePoints.size();
		quickSort(0, numCorePoint - 1);
		
		for (int i = 0; i < numCorePoint; i++) {
			mCorePoints.get(i).inSortCoreId = i;
		}
		
		mClusterID = 0;		
		for (int i = 0; i < numCorePoint; i++) {
			
			if (mCorePoints.get(i).visited)
				continue;
			
			mCorePoints.get(i).cluster = mClusterID;
			mClusterID++;
			
			Queue<DPoint> qDPoints = new LinkedList<>(); 
			qDPoints.offer(mCorePoints.get(i));

			while (!qDPoints.isEmpty()) {
				DPoint curPoint = qDPoints.remove();
				curPoint.visited = true;
				
				for (int j = curPoint.inSortCoreId + 1; j < numCorePoint; j++) {
					DPoint comparePoint = mCorePoints.get(j);
					if (comparePoint.visited)
						continue;
					
					double distTemp = dataset.get(comparePoint.inOrigId).data - dataset.get(curPoint.inOrigId).data;
					if (distTemp <= eps) {
						comparePoint.cluster = mCorePoints.get(i).cluster;
						comparePoint.visited = true;
						qDPoints.add(comparePoint);
						dataset.get(comparePoint.inOrigId).cluster = comparePoint.cluster;
					} else {
						break;
					}
				}
			}
		}
		
		for (int i = 0; i < numPoint; i++) {
			if (!dataset.get(i).pointType.equals("PointType_CORE")) {
				for (int j = 0; j < numCorePoint; j++) {
					double distTemp = distance(dataset.get(i), dataset.get(mCorePoints.get(j).inOrigId));
					if (distTemp <= eps) {
						dataset.get(i).pointType = "PointType_BORDER";
						dataset.get(i).cluster = mCorePoints.get(j).cluster;
						break;
					}
				}
			}

		}		
		
		Map<Integer, ArrayList<Integer>> clusterIdToData = new HashMap<>();
		for (int i = 0; i < dataset.size(); i++) {
			int data = dataset.get(i).data;
			int clusterId = dataset.get(i).cluster;
			clusterIdToData.putIfAbsent(clusterId, new ArrayList<>());
			clusterIdToData.get(clusterId).add(data);
		}
		
		return clusterIdToData;
		
	}
	
	private double distance(DPoint a, DPoint b) {
		return Math.abs(a.data - b.data);
	}
	
	private void quickSort(int low, int high) {
		
		int i = low;
		int j = high;
		if (low < high) {
			DPoint temp = mCorePoints.get(low);
			while (i != j) {
				while (j > i && mCorePoints.get(j).data >= temp.data) {
					--j;
				}
				if (i < j) {
					mCorePoints.set(i, mCorePoints.get(j));
					++i;
				}
				while (i < j && mCorePoints.get(i).data < temp.data) {
					++i;
				}
				if (i < j) {
					mCorePoints.set(j, mCorePoints.get(i));
					--j;
				}
			}
			mCorePoints.set(i, temp);
			quickSort(low, i - 1);
			quickSort(i + 1, high);
		}
		
	}

}
