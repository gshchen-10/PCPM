package utils;

import java.text.DecimalFormat;

public class PeriodicClusterPattern {
	
	private int productId;
	private int clusterNum;
	private float noiseRatio;
	private float averagePeriod;
	private float standVari;
	
	public PeriodicClusterPattern(int prodID, int clustNum, float noiseRat, float avePeri, float standvar) {
		
		this.productId = prodID;
		this.clusterNum = clustNum;
		this.noiseRatio = noiseRat;
		this.averagePeriod = avePeri;
		this.standVari = standvar;
		
	}
	
	public int getProductId() {
		return productId;
	}

	public void setProductId(int prodId) {
		this.productId = prodId;
	}

	public int getClusterNum() {
		return clusterNum;
	}

	public void setClusterNum(int clustNum) {
		this.clusterNum = clustNum;
	}

	public float getNoiseRatio() {
		return noiseRatio;
	}

	public void setNoiseRatio(float noiseRat) {
		this.noiseRatio = noiseRat;
	}

	public float getAveragePeriod() {
		return averagePeriod;
	}

	public void setAveragePeriod(float avePeriod) {
		this.averagePeriod = avePeriod;
	}
	
	public float getStandVari() {
		return standVari;
	}

	public void setStandVari(float standvar) {
		this.standVari = standvar;
	}

	public String toString() {
		
		DecimalFormat df =new DecimalFormat("#0.0000");	
		
		String str = "";
		str = "productId: " + productId + "  averagePeriod: " + df.format(averagePeriod) + "  noiseRatio: " + df.format(noiseRatio) + "  standVari: " + df.format(standVari) +"  " + standVari/ averagePeriod;
		return str;
	}

}
