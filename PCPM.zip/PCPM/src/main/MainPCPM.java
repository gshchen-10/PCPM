package main;

import java.text.ParseException;
import utils.PCPMiner;

public class MainPCPM {

	public static void main(String[] args) throws ParseException {	
		
		String dataset = "tafeng";   // tafeng  coop x5retailhero  tmall
		
		String inputPath = ".\\data\\" + dataset + ".txt";
		
		float coefficientOfVariation = 0.5f;
		float noiseRatio = 0.2f;
		int epsilon = 1;
		float minPtsRatio = 2.8f;

		PCPMiner pcpminer = new PCPMiner(inputPath);
		pcpminer.Running(coefficientOfVariation, noiseRatio, epsilon, minPtsRatio);
		pcpminer.printStatistics(dataset);		

	}

}
